﻿using System;
using System.Collections.Generic;

namespace Fulbi.Models
{
    public partial class Fecha
    {
        public Fecha()
        {
            Partidos = new HashSet<Partido>();
        }

        public int IdFecha { get; set; }
        public string Nombre { get; set; } = null!;
        public int IdTorneo { get; set; }

        public virtual Torneo IdTorneoNavigation { get; set; } = null!;
        public virtual ICollection<Partido> Partidos { get; set; }
    }
}
