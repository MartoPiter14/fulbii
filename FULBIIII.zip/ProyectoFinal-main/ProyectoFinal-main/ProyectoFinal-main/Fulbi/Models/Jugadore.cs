﻿using System;
using System.Collections.Generic;

namespace Fulbi.Models
{
    public partial class Jugadore
    {
        public int Id { get; set; }
        public string Nombre { get; set; } = null!;
        public string Apellido { get; set; } = null!;
        public int Dorsal { get; set; }
        public DateTime FechaNacimiento { get; set; }
        public int IdEquipo { get; set; }

        public virtual Equipo IdEquipoNavigation { get; set; } = null!;
    }
}
