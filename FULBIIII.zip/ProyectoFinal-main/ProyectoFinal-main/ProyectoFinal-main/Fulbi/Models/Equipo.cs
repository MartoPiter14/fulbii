﻿using System;
using System.Collections.Generic;

namespace Fulbi.Models
{
    public partial class Equipo
    {
        public Equipo()
        {
            Jugadores = new HashSet<Jugadore>();
            PartidoIdEquipo01Navigations = new HashSet<Partido>();
            PartidoIdEquipo02Navigations = new HashSet<Partido>();
        }

        public int IdEquipo { get; set; }
        public string Nombre { get; set; } = null!;
        public int IdTorneo { get; set; }

        public virtual Torneo IdTorneoNavigation { get; set; } = null!;
        public virtual ICollection<Jugadore> Jugadores { get; set; }
        public virtual ICollection<Partido> PartidoIdEquipo01Navigations { get; set; }
        public virtual ICollection<Partido> PartidoIdEquipo02Navigations { get; set; }
    }
}
