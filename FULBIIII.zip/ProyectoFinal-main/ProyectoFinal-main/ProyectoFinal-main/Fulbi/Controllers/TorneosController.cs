﻿using Fulbi.Models;
using Microsoft.AspNetCore.Mvc;
using System.Linq;
using Microsoft.EntityFrameworkCore;

namespace Fulbi.Controllers
{
    public class TorneosController : Controller
    {
        private readonly FulbiContext _context;

        public TorneosController(FulbiContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index()
        {
            return View(await _context.Torneos.ToListAsync());
        }

        public async Task<IActionResult> UnTorneo(int id)
        {

            //SELECT  * FRom Toprneros where id = id
            ViewBag.Id = id;
            Torneo t = _context.Torneos.SingleOrDefault(e => e.IdTorneo == id);
            return View(t);
        }
    }
}
